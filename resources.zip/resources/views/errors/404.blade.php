@extends('index')

@section('title')
  Pagina inesistente
@endsection

@section('content')
  <div class="container mt-5">
    <div class="row">
      <div class="col-12 text-center">
        <h1 class="text-danger">Mi spiace, la pagina a cui tenti di accedere non esiste :(</h1>
      </div>
    </div>
  </div>

@endsection
