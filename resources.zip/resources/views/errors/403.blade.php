@extends('index')

@section('title')
  Pagina bloccata
@endsection

@section('content')
  <div class="container mt-5">
    <div class="row">
      <div class="col-12 text-center">
        <h1 class="text-danger">Mi spiace, non hai il permesso di accedere a questa pagina.</h1>
      </div>
    </div>
  </div>

@endsection
